import React, { useState, useEffect } from "react";
/*
  INSTRUCTION:
  - import fetchGames, fetchGenres, fetchPlatforms, fetchYears, and API_URL from the utils/api.js file
*/

function App() {
  /*
  INSTRUCTIONS:
  - use useState to store the data for the games, genres, platforms, and years
  - use useState to store the data for the genre, platform, year, search, and sort
  */

  /*
  INSTRUCTIONS:
  - use useEffect to fetch the data for the games using the fetchGames function
  - use useEffect to fetch the data for the genres using the fetchGenres function
  - use useEffect to fetch the data for the platforms using the fetchPlatforms function
  - use useEffect to fetch the data for the years using the fetchYears function
  */

  return (
    <div className="app">
      <h1>Video Games</h1>
      {/*
      INSTRUCTIONS:
      - Add a search input for searching by title
      - Add a selector for filtering by genre
      - Add a selector for filtering by platform
      - Add a selector for filtering by year
      - Add a selector for sorting
      */}

      {/*
      INSTRUCTIONS:
      - Display the games in the following card format:
        - 3 columns in a row for desktop
        - 2 columns in a row for tablet
        - 1 column in a row for mobile
      - For each game, display the following information in the card:
        - Game image (use API_URL + game.image as the src)
        - Game genre
        - Game title
        - Game platform
        - Game year
      - If no games are found, display a message saying "No games found"
      */}
    </div>
  );
}

export default App;
