import axios from "axios";

/*
  INSTRUCTIONS:
  - create and export a constant API_URL that contains the base URL for the API
  - create a function fetchGames that fetches the games from the API
  - create a function fetchGenres that fetches the genres from the API
  - create a function fetchPlatforms that fetches the platforms from the API
  - create a function fetchYears that fetches the unique years from the games data
*/
